/*
 * fsm.c
 *  Created on: Nov 11, 2024
 *      Author: l1ttled1no
 */

#include "global.h"

int autoState_H = INIT;
int autoState_V = INIT;
int manState    = IDLE;

int redDur = 5;
int yelDur = 2;
int grnDur = 3;

int tempRed = 1;
int tempYel = 1;
int tempGrn = 1;

int horCount = 0;
int verCount = 0;
int scan     = 0;

void segmentUpdateAuto(void){
  updateSegment2Digits(horCount, verCount);
}

static void button0Signal(void){
  if (isButtonNoPressed(0) == 1){
    resetTimer(-1);
    horCount = 0; verCount = 0;
    updateSegment(IDLE, IDLE, IDLE, IDLE);
    scan = 0;
    setLedH(IDLE);
    setLedV(IDLE);
    autoState_H = IDLE;
    autoState_V = IDLE;
    manState    = MAN_RED;
    set1(100);
    set3(250);
  }
}

void fsm_run(void){
  fsm_auto_hor();
  fsm_auto_ver();
  fsm_man();
}

/* -------------------- AUTO HORIZONTAL -------------------- */
void fsm_auto_hor(void){
  switch (autoState_H){
    case INIT:
      set1(redDur * 1000);   // timer pha H
      set2(1000);            // nhịp 1s H
      set3(250);             // quét 7-seg
      horCount   = redDur;   // ✅ KHÔNG -1
      autoState_H = RED;
      break;

    case RED:
      setLedH(RED);

      if (flag1){                      // ✅ đổi pha trước
        set1(grnDur * 1000);
        horCount    = grnDur;          // ✅ KHÔNG -1
        set2(1000);                    // ✅ reset nhịp 1s khi vào state mới
        autoState_H = GRN;
      }

      if (flag2){                      // ✅ mỗi 1s mới trừ
        if (horCount > 0) horCount--;
        set2(1000);
      }

      if (flag3){
        segmentUpdateAuto();
        scan ^= 1;
        scan7Seg(scan);
        set3(250);
      }
      button0Signal();
      break;

    case GRN:
      setLedH(GRN);

      if (flag1){
        set1(yelDur * 1000);
        horCount    = yelDur;          // ✅ KHÔNG -1
        set2(1000);
        autoState_H = YEL;
      }

      if (flag2){
        if (horCount > 0) horCount--;
        set2(1000);
      }

      if (flag3){
        segmentUpdateAuto();
        scan ^= 1;
        scan7Seg(scan);
        set3(250);
      }
      button0Signal();
      break;

    case YEL:
      setLedH(YEL);

      if (flag1){
        set1(redDur * 1000);
        horCount    = redDur;          // ✅ KHÔNG -1
        set2(1000);
        autoState_H = RED;
      }

      if (flag2){
        if (horCount > 0) horCount--;
        set2(1000);
      }

      if (flag3){
        segmentUpdateAuto();
        scan ^= 1;
        scan7Seg(scan);
        set3(250);
      }
      button0Signal();
      break;

    default: /* IDLE */ break;
  }
}

/* -------------------- AUTO VERTICAL -------------------- */
void fsm_auto_ver(void){
  switch (autoState_V){
    case INIT:
      set4(grnDur * 1000);   // timer pha V
      set5(1000);            // nhịp 1s V
      verCount    = grnDur;  // ✅ KHÔNG -1
      autoState_V = GRN;
      break;

    case GRN:
      setLedV(GRN);

      if (flag4){                      // đổi pha trước
        set4(yelDur * 1000);
        verCount    = yelDur;          // ✅ KHÔNG -1
        set5(1000);
        autoState_V = YEL;
      }

      if (flag5){
        if (verCount > 0) verCount--;
        set5(1000);
      }
      break;

    case YEL:
      setLedV(YEL);

      if (flag4){
        set4(redDur * 1000);
        verCount    = redDur;          // ✅ KHÔNG -1
        set5(1000);
        autoState_V = RED;
      }

      if (flag5){
        if (verCount > 0) verCount--;
        set5(1000);
      }
      break;

    case RED:
      setLedV(RED);

      if (flag4){
        set4(grnDur * 1000);
        verCount    = grnDur;          // ✅ KHÔNG -1
        set5(1000);
        autoState_V = GRN;
      }

      if (flag5){
        if (verCount > 0) verCount--;
        set5(1000);
      }
      break;

    default: break;
  }
}

/* -------------------- MANUAL MODES -------------------- */
void fsm_man(void){
  switch (manState){
    case MAN_RED:
      updateSegment2Digits(tempRed, 02);

      if (isButtonNoPressed(0) == 1){
        tempRed  = 1;                 // discard change
        manState = MAN_YEL;
        setLedV(IDLE);
        setLedH(IDLE);
        set1(100);
        set3(250);
      }

      if (isButtonNoPressed(1) == 1){
        tempRed = (tempRed == 99) ? 1 : tempRed + 1;
      }

      if (isButtonNoPressed(2) == 1){
        redDur = tempRed;
      }

      if (flag1){                      // blink 2Hz (500ms)
        HAL_GPIO_TogglePin(red_h_GPIO_Port, red_h_Pin);
        HAL_GPIO_TogglePin(red_v_GPIO_Port, red_v_Pin);
        set1(500);
      }

      if (flag3){
        scan ^= 1;
        scan7Seg(scan);
        set3(250);
      }
      break;

    case MAN_YEL:
      updateSegment2Digits(tempYel, 03);

      if (isButtonNoPressed(0) == 1){
        tempYel  = 1;                 // discard change
        manState = MAN_GRN;
        setLedV(IDLE);
        setLedH(IDLE);
        set1(100);
        set3(250);
      }

      if (isButtonNoPressed(1) == 1){
        tempYel = (tempYel == 99) ? 1 : tempYel + 1;
      }

      if (isButtonNoPressed(2) == 1){
        yelDur = tempYel;
      }

      if (flag1){
        HAL_GPIO_TogglePin(yel_h_GPIO_Port, yel_h_Pin);
        HAL_GPIO_TogglePin(yel_v_GPIO_Port, yel_v_Pin);
        set1(500);
      }

      if (flag3){
        scan ^= 1;
        scan7Seg(scan);
        set3(250);
      }
      break;

    case MAN_GRN:
      updateSegment2Digits(tempGrn, 04);

      if (isButtonNoPressed(0) == 1){
        // Ràng buộc thời gian cơ bản
        if (yelDur > grnDur){
          grnDur += yelDur;
        }
        if (redDur < grnDur + yelDur){
          redDur = grnDur + yelDur;
        }
        if (grnDur >= redDur + yelDur){
          grnDur = redDur - yelDur;
        }

        // thông báo OK (hiển thị ALL & 8)
        setLedH(ALL);
        setLedV(ALL);




        setLedV(IDLE);
        setLedH(IDLE);
        resetTimer(NONE);         // reset all timer

        manState    = IDLE;
        autoState_H = INIT;
        autoState_V = INIT;
        return;
      }

      if (isButtonNoPressed(1) == 1){
        tempGrn = (tempGrn == 99) ? 1 : tempGrn + 1;
      }

      if (isButtonNoPressed(2) == 1){
        grnDur = tempGrn;
      }

      if (flag1){
        HAL_GPIO_TogglePin(grn_h_GPIO_Port, grn_h_Pin);
        HAL_GPIO_TogglePin(grn_v_GPIO_Port, grn_v_Pin);
        set1(500);
      }

      if (flag3){
        scan ^= 1;
        scan7Seg(scan);
        set3(250);
      }
      break;

    default: break;
  }
}
